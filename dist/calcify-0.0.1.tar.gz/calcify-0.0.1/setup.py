from setuptools import setup


setup(
    name='Calcify',
    version='0.0.1',
    description="A calculus library for python",
    author="Brady Call",
    author_email="wbradycall@gmail.com",
    packages=['calcify'],
    intall_requires=['numpy']
)